Inkscape_LivingHinge
====================

An Inkscape extension for automating the process of adding cut lines to create a living hinge.

To install:
copy living_hinge.inx and living_hinge.py to the inkscape/extensions directory on your computer.
