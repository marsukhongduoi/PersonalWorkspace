#!/bin/bash
#export SUDO_ASKPASS=/usr/bin/ssh-askpass 
#sudo cp living_hinge.inx /usr/share/inkscape/extensions/
#sudo cp src/living_hinge.py /usr/share/inkscape/extensions/
cp living_hinge.inx ~/.config/inkscape/extensions
cp src/living_hinge.py ~/.config/inkscape/extensions
